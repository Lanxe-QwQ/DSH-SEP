// D:/AIData/ProjectWork/DSH/rc2-adaptation-20261018-r1/official-source/packages/client/tsdown.client.ts
import { readFile, stat, utimes } from "node:fs/promises";
import { existsSync as existsSync2, readFileSync as readFileSync2 } from "node:fs";
import { createRequire, isBuiltin } from "node:module";
import { basename, dirname as dirname2, extname, isAbsolute as isAbsolute2, relative as relative2, resolve as resolvePath, sep as sep2 } from "node:path";
import { Rolldown } from "file:///D:/AIData/ProjectWork/DSH/dsh-020rc2-20260929/upstream/node_modules/.pnpm/tsdown@0.22.2_oxc-resolver@_f113eb69000457c8d5954142d0822f52/node_modules/tsdown/dist/index.mjs";
import { transform } from "file:///D:/AIData/ProjectWork/DSH/dsh-020rc2-20260929/upstream/node_modules/.pnpm/lightningcss@1.32.0/node_modules/lightningcss/node/index.js";

// D:/AIData/ProjectWork/DSH/rc2-adaptation-20261018-r1/official-source/packages/client/modules/src/client/manifest.ts
function optionalStringArray(subject, field, value) {
  if (value === void 0) return void 0;
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
    throw new Error(`client-modules: ${subject} ${field} must be a string array`);
  }
  return value;
}

// D:/AIData/ProjectWork/DSH/rc2-adaptation-20261018-r1/official-source/packages/client/web/src/platform.ts
var PLATFORM_MODULES = [
  "react",
  "react/jsx-runtime",
  "react-dom",
  "react-dom/client",
  "@deepseek-ai/cordis",
  "zod",
  "@tanstack/react-virtual",
  "@deepseek-ai/dsh-client-store",
  "@deepseek-ai/dsh-client-ui-slots",
  "@deepseek-ai/dsh-client-ui-primitives",
  "@deepseek-ai/dsh-client-ui-dockkit"
];
var PRELOADED_CLIENT_EXTERNALS = [];

// D:/AIData/ProjectWork/DSH/rc2-adaptation-20261018-r1/official-source/scripts/client-build-environment.ts
var CLIENT_BUILD_ENV_PREFIX = "DSH_CLIENT_";
function clientBuildEnvironment(environment) {
  return Object.fromEntries(Object.entries(environment).filter(([name, value]) => name.startsWith(CLIENT_BUILD_ENV_PREFIX) && value !== void 0).sort(([left], [right]) => left.localeCompare(right)));
}
function clientBuildEnvironmentDefines(environment) {
  return { "process.env": "{}", ...clientBuildValueDefines(environment) };
}
function clientBuildValueDefines(environment) {
  const defines = {};
  for (const [name, value] of Object.entries(clientBuildEnvironment(environment))) {
    defines[`process.env.${name}`] = JSON.stringify(value);
  }
  return defines;
}

// D:/AIData/ProjectWork/DSH/rc2-adaptation-20261018-r1/official-source/scripts/experimental-package-policy.ts
var EXPERIMENTAL_PACKAGE_NAME_EXCEPTIONS = {
  "packages/experimental/cua": "@deepseek-ai/dsh-cua",
  "packages/experimental/tool-session-query": "@deepseek-ai/dsh-tool-session-query",
  "packages/experimental/session-title-all-prompts-llm": "@deepseek-ai/dsh-session-title-all-prompts-llm",
  "packages/experimental/tool-terminal": "@deepseek-ai/dsh-tool-terminal",
  "packages/experimental/tool-ralph": "@deepseek-ai/dsh-tool-ralph",
  "packages/experimental/skill-badge": "@deepseek-ai/dsh-skill-badge",
  "packages/experimental/hook-protocol": "@deepseek-ai/dsh-hook-protocol",
  "packages/experimental/hooks-claude-code": "@deepseek-ai/dsh-hooks-claude-code",
  "packages/experimental/hooks-codex": "@deepseek-ai/dsh-hooks-codex",
  "packages/experimental/webhook": "@deepseek-ai/dsh-webhook",
  "packages/experimental/webhook-github": "@deepseek-ai/dsh-webhook-github"
};
var EXPERIMENTAL_PACKAGE_NAME_PREFIX = "@deepseek-ai/dsh-experimental-";
var retainedNames = new Set(Object.values(EXPERIMENTAL_PACKAGE_NAME_EXCEPTIONS));
function isExperimentalPackageName(name) {
  return name.startsWith(EXPERIMENTAL_PACKAGE_NAME_PREFIX) || retainedNames.has(name);
}
function hasExperimentalPackageReference(reference) {
  const normalized = reference.replaceAll("\\", "/");
  return [...normalized.matchAll(/(?:^|[/:\u0000])(@deepseek-ai\/[^/@?#:\s]+)(?=$|[/@?#:])/g)].some(([, name]) => name !== void 0 && isExperimentalPackageName(name));
}

// D:/AIData/ProjectWork/DSH/rc2-adaptation-20261018-r1/official-source/scripts/bundle-input-isolation.ts
import { existsSync, readFileSync, realpathSync } from "node:fs";
import { dirname, isAbsolute, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
var BundleInputIsolation = class {
  packages = /* @__PURE__ */ new Map();
  repository;
  label;
  constructor(repository, label) {
    this.repository = repository;
    this.label = label;
  }
  /** Discard package metadata before a new build or watch rebuild. */
  reset() {
    this.packages.clear();
  }
  /**
   * Require a recorded input to have non-experimental physical and package ownership.
   * @param id - bundler module id, filesystem path, or filesystem URL.
   */
  assertInput(id) {
    this.checkInput(id, false);
  }
  /**
   * Check declared source-map ownership; dependency tarballs may omit their upstream sources.
   * @param id - source-map source resolved relative to its map.
   */
  assertSourceMapInput(id) {
    this.checkInput(id, true);
  }
  checkInput(id, allowMissing) {
    if (hasExperimentalPackageReference(id)) {
      throw new Error(`${this.label}: experimental input ${id}`);
    }
    const file = physicalBundleInput(id);
    if (file === void 0) return;
    const lexical = relative(resolve(this.repository, "packages/experimental"), file);
    if (lexical === "" || lexical !== ".." && !lexical.startsWith(`..${sep}`) && !isAbsolute(lexical)) {
      throw new Error(`${this.label}: experimental input ${id}`);
    }
    let existing = file;
    if (!allowMissing && !existsSync(file)) throw new Error(`${this.label}: input ${id} is missing`);
    while (!existsSync(existing)) {
      const parent = dirname(existing);
      if (parent === existing) throw new Error(`${this.label}: input ${id} has no existing filesystem root`);
      existing = parent;
    }
    const canonical = resolve(realpathSync(existing), relative(existing, file));
    if (canonical !== file) this.checkInput(canonical, allowMissing);
    const name = this.packageName(dirname(canonical));
    if (name !== void 0 && isExperimentalPackageName(name)) {
      throw new Error(`${this.label}: ${id} belongs to experimental package ${name}`);
    }
  }
  packageName(directory) {
    if (this.packages.has(directory)) return this.packages.get(directory);
    const manifest = resolve(directory, "package.json");
    let name;
    if (existsSync(manifest)) {
      const value = JSON.parse(readFileSync(manifest, "utf8"));
      if (value !== null && typeof value === "object" && "name" in value && typeof value.name === "string") name = value.name;
    }
    if (name === void 0 && dirname(directory) !== directory) name = this.packageName(dirname(directory));
    this.packages.set(directory, name);
    return name;
  }
};
function physicalBundleInput(id) {
  let clean = id.replaceAll("\\", "/").split(/[?#]/, 1)[0] ?? "";
  clean = clean.replace(/^\u0000/, "");
  if (clean.startsWith("file://")) return fileURLToPath(clean);
  if (clean.startsWith("/@fs/")) {
    clean = clean.slice("/@fs/".length);
    if (!isAbsolute(clean) && !/^[a-zA-Z]:\//.test(clean)) clean = `/${clean}`;
  }
  if (!isAbsolute(clean) && !/^[a-zA-Z]:\//.test(clean)) {
    const wrapped = /:(\/.*|[a-zA-Z]:\/.*)$/.exec(clean)?.[1];
    if (wrapped === void 0) return void 0;
    clean = wrapped;
  }
  return resolve(clean);
}

// D:/AIData/ProjectWork/DSH/rc2-adaptation-20261018-r1/official-source/packages/client/tsdown.client.ts
var CSS_VIRTUAL_PREFIX = "\0dsh-css:";
var GLOBAL_CSS_VIRTUAL_PREFIX = "\0dsh-global-css:";
var INLINE_CSS_VIRTUAL_PREFIX = "\0dsh-inline-css:";
var CSS_VIRTUAL_SUFFIX = ".mjs";
var INLINE_CSS_QUERY = "?inline";
var IMAGE_MEDIA_TYPES = /* @__PURE__ */ new Map([[".svg", "image/svg+xml"], [".png", "image/png"], [".webp", "image/webp"]]);
function styleInjectionModule(id, fileId, css, classMap) {
  const source = [
    `const css = ${JSON.stringify(css)};`,
    `const tagId = ${JSON.stringify(`${id}/${basename(fileId)}`)};`,
    "if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css=' + JSON.stringify(tagId) + ']') === null) {",
    "  const tag = document.createElement('style');",
    `  tag.dataset.plugin = ${JSON.stringify(id)};`,
    "  tag.dataset.pluginCss = tagId;",
    "  tag.textContent = css;",
    "  document.head.appendChild(tag);",
    "}"
  ];
  source.push(classMap === void 0 ? "export {};" : `export default ${JSON.stringify(classMap)};`);
  return source.join("\n");
}
var INLINE_SAFE = /^(?:@deepseek-ai\/dsh-(?:file-reference|session|llm|tools|brand|deque|output-retention|typert-protocol|util-crypto|util-values|util-workspace-path)(?:\/|$)|@deepseek-ai\/dsh-token-meter\/client$|@deepseek-ai\/dsh-native-command\/types$|@deepseek-ai\/dsh-host-open-in-app\/shared$|@deepseek-ai\/dsh-plugin-manager\/registry$|@deepseek-ai\/dsh-agent-preset-registry\/display$|@deepseek-ai\/dsh-api-workspace-controller\/default-workspace$|@deepseek-ai\/dsh-spill-policy\/notice$)/;
var VENDORED_LIBRARY = /^@deepseek-ai\/(cosmokit|schemastery)(\/|$)/;
var GENERATED_REMOTE = /^@deepseek-ai\/dsh-[a-z0-9]+(?:-[a-z0-9]+)*\/remote$/;
var SKIP_WORKSPACE_BUILD = { entry: "" };
var REPOSITORY_ROOT = "D:\\AIData\\ProjectWork\\DSH\\rc2-adaptation-20261018-r1\\desktop-source";
function browserSourcePath(source, sourcemapPath) {
  if (!source.startsWith(".")) return source;
  const physicalSource = resolvePath(dirname2(sourcemapPath), source);
  const repositoryPath = relative2(REPOSITORY_ROOT, physicalSource).split(sep2).join("/");
  return repositoryPath.startsWith("packages/") ? `../../../${repositoryPath}` : source;
}
function clientBundle(packageDir, libEntry, options = {}) {
  const manifest = readPackageManifest(packageDir);
  const lib = clientLibraryConfig(manifest, libEntry, options.lib);
  return ({ env }) => {
    const face = buildFace(env?.DSH_BUILD_FACE);
    const clientEntry = face === void 0 ? "src/client/index.ts" : "lib/types/client/index.js";
    const client = clientConfig(manifest, clientEntry, options.clientBanner, options.dualClient === true);
    const node = [lib, ...options.companions ?? []];
    const clientFaces = options.dualClient === true ? [nodeClientConfig(manifest, clientEntry), client] : [client];
    if (face === "host") return options.hostPhase === true ? node : [SKIP_WORKSPACE_BUILD];
    if (face === "client") {
      return options.hostPhase === true ? clientFaces : [...node, ...clientFaces];
    }
    return [...node, ...clientFaces];
  };
}
function buildFace(value) {
  if (value === void 0 || value === "host" || value === "client") return value;
  throw new Error(`tsdown: --env.DSH_BUILD_FACE must be host or client, received ${String(value)}`);
}
function clientLibraryConfig(manifest, libEntry, overrides = {}) {
  let externals;
  const isProductionDependency = (specifier) => matchesSpecifier(externals ??= productionExternals(manifest), specifier);
  return {
    name: manifest.name,
    entry: [...libEntry],
    outDir: "lib",
    format: ["esm"],
    platform: "node",
    target: "es2024",
    fixedExtension: false,
    dts: false,
    clean: false,
    // Public client build values are fixed into the Node half as they are into the browser half.
    define: clientBuildValueDefines(process.env),
    deps: {
      // The Node half runs from a real install: a production dependency is on
      // disk there and stays an import, everything else inlines. Stating both
      // halves takes the artifact off tsdown's getProductionDeps fallback, where
      // moving a dependency between npm sections silently re-bundles it.
      // Builtins keep tsdown's own handling (neither side claims them).
      neverBundle: isProductionDependency,
      alwaysBundle: (specifier) => !isBuiltin(specifier) && !isProductionDependency(specifier)
    },
    ...overrides
  };
}
function readPackageManifest(packageDir) {
  const manifestPath = resolvePath(packageDir, "package.json");
  let parsed;
  try {
    parsed = JSON.parse(readFileSync2(manifestPath, "utf8"));
  } catch (error) {
    throw new Error(
      `tsdown: cannot read ${manifestPath}; pass the package directory (the import.meta.dirname of its tsdown.config.ts)`,
      { cause: error }
    );
  }
  if (typeof parsed !== "object" || parsed === null || !("name" in parsed) || typeof parsed.name !== "string") {
    throw new Error(`tsdown: ${manifestPath} declares no string package name`);
  }
  return parsed;
}
function productionExternals(manifest) {
  const names = /* @__PURE__ */ new Set([
    ...Object.keys(manifest.dependencies ?? {}),
    ...Object.keys(manifest.peerDependencies ?? {}),
    ...Object.keys(manifest.optionalDependencies ?? {})
  ]);
  return [...names].sort().map((name) => new RegExp(`^${escapeSpecifier(name)}(/|$)`));
}
function requestedExternals(subject, declaration) {
  return new Set(optionalStringArray(subject, "dsh.client.external", declaration.external) ?? []);
}
function clientExternals(manifest) {
  return /* @__PURE__ */ new Set([
    ...PLATFORM_MODULES,
    ...PRELOADED_CLIENT_EXTERNALS,
    ...requestedExternals(manifest.name, manifest.dsh?.client ?? {})
  ]);
}
function escapeSpecifier(name) {
  return name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function matchesSpecifier(patterns, specifier) {
  return patterns.some((pattern) => pattern.test(specifier));
}
function asyncChunkRequirePlugin() {
  return {
    name: "dsh-client-async-chunk-require",
    renderChunk(code, chunk, outputOptions) {
      if (outputOptions.format !== "cjs") return null;
      const transformed = new Rolldown.RolldownMagicString(code);
      for (const dynamicImport of chunk.dynamicImports) {
        const fileName = dynamicImport.startsWith("./") ? dynamicImport.slice(2) : dynamicImport;
        if (!/^client\.[A-Za-z0-9][A-Za-z0-9._-]*\.js$/.test(fileName)) continue;
        const specifier = `./${fileName}`;
        const call = new RegExp(
          `Promise\\.resolve\\(\\)\\.then\\(\\(\\)\\s*=>\\s*require\\((['"])${escapeSpecifier(specifier)}\\1\\)\\)`,
          "gu"
        );
        const matches = [...code.matchAll(call)];
        if (matches.length === 0) {
          throw new Error(`client bundle compiler: dynamic chunk ${JSON.stringify(specifier)} has no generated import expression`);
        }
        for (const match of matches) {
          transformed.overwrite(match.index, match.index + match[0].length, `require.async(${JSON.stringify(specifier)})`);
        }
      }
      return transformed.hasChanged() ? transformed : null;
    },
    async writeBundle(outputOptions, bundle) {
      const entry = Object.values(bundle).find((output) => output.type === "chunk" && output.isEntry);
      if (entry === void 0 || outputOptions.dir === void 0) return;
      const entryPath = resolvePath(outputOptions.dir, entry.fileName);
      const current = await stat(entryPath);
      const completedAt = new Date(Math.max(Date.now(), current.mtimeMs + 1));
      await utimes(entryPath, current.atime, completedAt);
    }
  };
}
function nodeClientConfig(manifest, entry) {
  const isolation = clientInputIsolation(manifest.name);
  return clientLibraryConfig(manifest, [entry], {
    name: `${manifest.name}/client-node`,
    entry: { "client.node": entry },
    sourcemap: true,
    inputOptions: { resolve: { conditionNames: ["node", "import", "module", "default"] } },
    plugins: [tscSourceMapPlugin(), isolation.plugin],
    outputOptions: {
      entryFileNames: "client.node.js",
      chunkFileNames: "client.node.[name].js",
      sourcemapExcludeSources: false,
      sourcemapPathTransform: isolation.sourcePath
    }
  });
}
function clientConfig(manifest, entry, clientBanner, dualClient = false) {
  const id = manifest.name;
  let requested;
  const isRequested = (specifier) => (requested ??= clientExternals(manifest)).has(specifier);
  const isolation = clientInputIsolation(id);
  return {
    name: `${id}/client`,
    entry: { client: entry },
    // Browser bundle lands beside the Node artifacts. clean must stay off:
    // cleaning this invocation would wipe the independently emitted Node entry.
    outDir: "lib",
    format: "cjs",
    platform: "browser",
    // Types ship from lib/types (tsc); dts here would wrap the banner/footer into .d.cts and break parsing.
    dts: false,
    // Plugin code is fetched outside Vite's module graph, so its own bundle
    // must carry the TS/TSX mapping consumed by browser profiling tools.
    sourcemap: true,
    clean: false,
    deps: {
      neverBundle: isRequested,
      // Anything NOT requested from the loader module table must inline
      // (wire/type layers, clsx — every non-shared dep). A require() the
      // table cannot answer is a guaranteed runtime throw, so the rule is the
      // package's own request list: requested specifiers stay imports,
      // everything else is bundled.
      alwaysBundle: (specifier) => !isRequested(specifier)
    },
    // Dual-mode libraries (lexical's exports carry development/production/
    // node conditions; the node file picks its flavor with a top-level await
    // a CJS bundle cannot carry) resolve their static flavor matching the
    // NODE_ENV the defines below bake in.
    inputOptions: {
      resolve: {
        conditionNames: [
          (process.env.NODE_ENV ?? "production") === "development" ? "development" : "production",
          "browser",
          "import",
          "module",
          "default"
        ]
      }
    },
    // Browser bundles inline node-idiom deps (zustand/immer read
    // process.env.NODE_ENV; zustand's esm build also probes
    // import.meta.env.MODE, which a CJS output cannot carry — rolldown flags
    // EMPTY_IMPORT_META). vite defined both on the seed path; tsdown inlining
    // needs the substitutions here or the factory throws ReferenceError at
    // boot / the build gate reds. Both keys honor the build's NODE_ENV so a
    // dev build keeps the dev-branch semantics; artifacts default to production.
    // The bare `import.meta.env` key is required alongside the precise MODE
    // key: zustand probes `import.meta.env ? import.meta.env.MODE : ...`, and
    // the truthiness probe would otherwise survive as an empty import.meta.
    define: {
      ...clientBuildEnvironmentDefines(process.env),
      "process.env.NODE_ENV": JSON.stringify(process.env.NODE_ENV ?? "production"),
      "import.meta.env.MODE": JSON.stringify(process.env.NODE_ENV ?? "production"),
      "import.meta.env": JSON.stringify({ MODE: process.env.NODE_ENV ?? "production" })
    },
    plugins: [{
      // Bundle purity gate (build-time mirror of the module-edge rules): the
      // baseline and package-specific requests stay external, inline-safe wire layers
      // inline, and every other @deepseek-ai value import is a build error — a
      // cross-plugin value import either inlines a duplicate runtime instance
      // or requires a specifier the module table cannot answer for this package.
      // Cross-plugin collaboration goes through cordis services instead.
      name: "dsh-client-bundle-purity",
      resolveId(source) {
        if (!source.startsWith("@deepseek-ai/")) return null;
        if (isRequested(source)) return null;
        if (VENDORED_LIBRARY.test(source)) return null;
        if (INLINE_SAFE.test(source) || GENERATED_REMOTE.test(source)) return null;
        throw new Error(
          `client bundle purity: "${source}" is not in the default client externals or ${id}'s dsh.client.external, an inline-safe wire layer, or a generated /remote contribution \u2014 cross-plugin value imports are forbidden; declare a non-default module request or collaborate through cordis services (type-only imports are erased and never reach this gate)`
        );
      }
    }, tscSourceMapPlugin(), asyncChunkRequirePlugin(), isolation.plugin, {
      name: "dsh-css-modules-inline",
      resolveId(source, importer) {
        if (!source.endsWith(".module.css")) return null;
        const abs = importer !== void 0 ? sourceAssetPath(source, importer) : source;
        return CSS_VIRTUAL_PREFIX + abs + CSS_VIRTUAL_SUFFIX;
      },
      async load(virtualId) {
        if (!virtualId.startsWith(CSS_VIRTUAL_PREFIX)) return null;
        const fileId = virtualId.slice(CSS_VIRTUAL_PREFIX.length, -CSS_VIRTUAL_SUFFIX.length);
        this.addWatchFile(fileId);
        const source = await readFile(fileId);
        const { code, exports: cssExports } = transform({
          filename: fileId,
          code: source,
          cssModules: { pattern: "[hash]_[local]" },
          minify: true
        });
        const classMap = {};
        const exportEntries = Object.entries(cssExports ?? {}).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0);
        for (const [local, exp] of exportEntries) classMap[local] = exp.name;
        return styleInjectionModule(id, fileId, code.toString(), classMap);
      }
    }, {
      name: "dsh-css-text-inline",
      resolveId(source, importer) {
        if (!source.endsWith(`.css${INLINE_CSS_QUERY}`)) return null;
        const stylesheet = source.slice(0, -INLINE_CSS_QUERY.length);
        const abs = importer !== void 0 ? sourceAssetPath(stylesheet, importer) : stylesheet;
        return INLINE_CSS_VIRTUAL_PREFIX + abs + CSS_VIRTUAL_SUFFIX;
      },
      async load(virtualId) {
        if (!virtualId.startsWith(INLINE_CSS_VIRTUAL_PREFIX)) return null;
        const fileId = virtualId.slice(INLINE_CSS_VIRTUAL_PREFIX.length, -CSS_VIRTUAL_SUFFIX.length);
        this.addWatchFile(fileId);
        const source = await readFile(fileId);
        const { code } = transform({ filename: fileId, code: source, minify: true });
        return `export default ${JSON.stringify(code.toString())};`;
      }
    }, {
      name: "dsh-css-global-inline",
      resolveId(source, importer) {
        if (!source.endsWith(".css") || source.endsWith(".module.css")) return null;
        const abs = importer !== void 0 ? sourceAssetPath(source, importer) : source;
        return GLOBAL_CSS_VIRTUAL_PREFIX + abs + CSS_VIRTUAL_SUFFIX;
      },
      async load(virtualId) {
        if (!virtualId.startsWith(GLOBAL_CSS_VIRTUAL_PREFIX)) return null;
        const fileId = virtualId.slice(GLOBAL_CSS_VIRTUAL_PREFIX.length, -CSS_VIRTUAL_SUFFIX.length);
        this.addWatchFile(fileId);
        const source = await readFile(fileId);
        const { code } = transform({ filename: fileId, code: source, minify: true });
        return styleInjectionModule(id, fileId, code.toString());
      }
    }, {
      name: "dsh-image-inline",
      resolveId(source, importer) {
        if (importer === void 0 || !IMAGE_MEDIA_TYPES.has(extname(source))) return null;
        return sourceAssetPath(source, importer);
      },
      async load(fileId) {
        const mediaType = IMAGE_MEDIA_TYPES.get(extname(fileId));
        if (mediaType === void 0) return null;
        this.addWatchFile(fileId);
        const data = await readFile(fileId);
        return `export default ${JSON.stringify(`data:${mediaType};base64,${data.toString("base64")}`)};`;
      }
    }],
    outputOptions: {
      entryFileNames: dualClient ? "client.browser.js" : "client.js",
      // The imported source basename becomes the published chunk name; package
      // files lists and artifact tests pin every intentional chunk.
      chunkFileNames: dualClient ? "client.browser.[name].js" : "client.[name].js",
      sourcemapExcludeSources: false,
      // The map is served from /plugins/<scoped-package>/client.js.map. The
      // browser resolves its local sources back into URLs that mirror the
      // /packages/<group>/<package>/src directories; sourcesContent keeps them usable
      // without exposing that tree as an HTTP route.
      sourcemapPathTransform(source, mapPath) {
        isolation.sourcePath(source, mapPath);
        return browserSourcePath(source, mapPath);
      },
      banner: (chunk) => {
        const registration = `window.__ModuleLoader__.load({ id: ${JSON.stringify(id)}, ${chunk.isEntry ? "" : `chunk: ${JSON.stringify(chunk.fileName)}, `}factory: (require) => {`;
        const prefix = clientBanner?.(chunk.fileName);
        return prefix === void 0 ? registration : `${prefix}
${registration}`;
      },
      footer: "return module.exports; } });",
      intro: "var module = { exports: {} }; var exports = module.exports;"
    }
  };
}
function clientInputIsolation(id) {
  const experimental = isExperimentalPackageName(id);
  const inputs = new BundleInputIsolation(REPOSITORY_ROOT, `client bundle isolation (${id})`);
  return {
    plugin: {
      name: "dsh-client-input-isolation",
      buildStart() {
        inputs.reset();
      },
      generateBundle(_options, bundle) {
        if (experimental) return;
        for (const output of Object.values(bundle)) {
          if (output.type === "chunk") {
            for (const module of Object.keys(output.modules)) {
              inputs.assertInput(clientInputFile(module));
              const info = this.getModuleInfo(module);
              if (info === null) {
                if (module === "\0rolldown/runtime.js") continue;
                throw new Error(`client bundle isolation (${id}): module ${module} has no bundler module record`);
              }
              for (const dependency of [...info.importedIds, ...info.dynamicallyImportedIds]) {
                inputs.assertInput(clientInputFile(dependency));
              }
            }
            for (const external of [...output.imports, ...output.dynamicImports]) {
              if (!(external in bundle)) inputs.assertInput(external);
            }
          } else {
            for (const original of output.originalFileNames) inputs.assertInput(original);
          }
        }
      }
    },
    sourcePath(source, mapPath) {
      if (!experimental) {
        const decoded = clientInputFile(source);
        const file = physicalBundleInput(decoded) ?? resolvePath(dirname2(mapPath), decoded);
        inputs.assertSourceMapInput(file);
      }
      return source;
    }
  };
}
function clientInputFile(id) {
  const prefix = [CSS_VIRTUAL_PREFIX, GLOBAL_CSS_VIRTUAL_PREFIX, INLINE_CSS_VIRTUAL_PREFIX].find((prefix2) => id.startsWith(prefix2));
  return prefix === void 0 ? id : id.slice(prefix.length, -CSS_VIRTUAL_SUFFIX.length);
}
function tscSourceMapPlugin() {
  return {
    name: "dsh-tsc-sourcemap",
    async load(id) {
      if (!id.includes(TYPES_MARKER) || !id.endsWith(".js") || !existsSync2(`${id}.map`)) return null;
      const code = await readFile(id, "utf8");
      const mapPath = `${id}.map`;
      const map = JSON.parse(await readFile(mapPath, "utf8"));
      if (!Array.isArray(map.sources) || map.sources.some((source) => typeof source !== "string")) {
        throw new Error(`client sourcemap: ${mapPath} has invalid sources`);
      }
      const sources = map.sources;
      if (!Array.isArray(map.sourcesContent) || map.sourcesContent.length !== sources.length || map.sourcesContent.some((source) => typeof source !== "string")) {
        const sourceRoot = typeof map.sourceRoot === "string" ? map.sourceRoot : "";
        map.sourcesContent = await Promise.all(sources.map(async (source) => await readFile(resolvePath(dirname2(mapPath), sourceRoot, source), "utf8")));
      }
      return { code: code.replace(SOURCEMAP_COMMENT, ""), map };
    }
  };
}
var TYPES_MARKER = `${sep2}lib${sep2}types${sep2}`;
var SOURCE_MARKER = `${sep2}src${sep2}`;
var SOURCEMAP_COMMENT = /\n\/\/# sourceMappingURL=.*\s*$/;
function sourceAssetPath(source, importer) {
  if (!source.startsWith(".") && !isAbsolute2(source)) return createRequire(importer).resolve(source);
  const emitted = resolvePath(dirname2(importer), source);
  if (existsSync2(emitted)) return emitted;
  const boundary = emitted.indexOf(TYPES_MARKER);
  if (boundary < 0) return emitted;
  return resolvePath(emitted.slice(0, boundary), "src", emitted.slice(boundary + TYPES_MARKER.length));
}

// D:/AIData/ProjectWork/DSH/rc2-adaptation-20261018-r1/desktop-source/packages/client/ui-settings-general/tsdown.config.ts
var tsdown_config_default = clientBundle("D:\\AIData\\ProjectWork\\DSH\\rc2-adaptation-20261018-r1\\desktop-source\\packages\\client\\ui-settings-general", ["lib/types/index.js"]);
export {
  tsdown_config_default as default
};
